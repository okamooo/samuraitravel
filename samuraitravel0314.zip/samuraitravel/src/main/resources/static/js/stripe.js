const stripe = Stripe('pk_test_51Qx1V8By52mpTfqUqpjk9qPVQoJZC8dEDBnhCB5XIORWsiwFejavvYMgsiZE5eUXqME9MAPC0LqXiSYp8PABAI9M00SWe3fYil');
const paymentButton = document.querySelector('#paymentButton');

paymentButton.addEventListener('click', () => {
 stripe.redirectToCheckout({
   sessionId: sessionId
 })
});